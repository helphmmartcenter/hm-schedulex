// HM ScheduleX - Popup Script
// Version: 1.22.0

// ─── LICENSE SYSTEM ──────────────────────────────────────────────────────────
const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxq8evWnW4OMrClRBFfFcNWJt_-RqqMZQk8ERQZSBnjSIgNVBC25fX1WaWQVLo_No3p/exec';

function doXHR(url, callback) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onload = () => {
    try { callback(JSON.parse(xhr.responseText)); }
    catch(e) { callback({ status: 'network_error' }); }
  };
  xhr.onerror = xhr.ontimeout = () => callback({ status: 'network_error' });
  xhr.timeout = 15000;
  xhr.send();
}

function getOrCreateDeviceId(callback) {
  chrome.storage.sync.get(['hmDeviceId'], r => {
    if (r.hmDeviceId) { callback(r.hmDeviceId); return; }
    const id = 'DEV-' + Date.now() + '-' + Math.random().toString(36).substr(2,9).toUpperCase();
    chrome.storage.sync.set({ hmDeviceId: id }, () => callback(id));
  });
}

function showLicenseScreen() {
  document.getElementById('licenseScreen').classList.remove('hidden');
  document.getElementById('revokedScreen').classList.add('hidden');
  document.getElementById('mainApp').classList.add('hidden');
}

function showRevokedScreen() {
  document.getElementById('licenseScreen').classList.add('hidden');
  document.getElementById('revokedScreen').classList.remove('hidden');
  document.getElementById('mainApp').classList.add('hidden');
}

function showMainApp() {
  document.getElementById('licenseScreen').classList.add('hidden');
  document.getElementById('revokedScreen').classList.add('hidden');
  document.getElementById('mainApp').classList.remove('hidden');
  // Auto update check
  setTimeout(checkForUpdate, 2000);
}

function checkLicense() {
  chrome.storage.sync.get(['hmRevoked', 'hmActivated', 'hmLicenseKey', 'hmDeviceId'], result => {
    // Pehle revoke check karo
    if (result.hmRevoked === true) {
      showRevokedScreen();
      return;
    }
    // Already activated?
    if (result.hmActivated && result.hmLicenseKey) {
      getOrCreateDeviceId(deviceId => {
        const url = `${APPS_SCRIPT_URL}?action=check&key=${result.hmLicenseKey}&device=${deviceId}`;
        doXHR(url, res => {
          if (res.status === 'active' || res.status === 'already_yours') {
            showMainApp();
          } else if (res.status === 'revoked') {
            chrome.storage.sync.set({ hmRevoked: true });
            showRevokedScreen();
          } else if (res.status === 'network_error') {
            // Grace mode — already activated tha, allow karo
            showMainApp();
          } else {
            showLicenseScreen();
          }
        });
      });
    } else {
      showLicenseScreen();
    }
  });
}

function handleActivation(key) {
  const btn = document.getElementById('btnActivate');
  const errorDiv = document.getElementById('licenseError');
  btn.disabled = true;
  btn.textContent = '⏳ Activating...';
  errorDiv.classList.add('hidden');

  getOrCreateDeviceId(deviceId => {
    const url = `${APPS_SCRIPT_URL}?action=activate&key=${key}&device=${deviceId}`;
    doXHR(url, res => {
      btn.disabled = false;
      btn.textContent = '🔓 Activate';
      if (res.status === 'activated' || res.status === 'already_yours') {
        chrome.storage.sync.set({ hmActivated: true, hmLicenseKey: key });
        showMainApp();
      } else if (res.status === 'used_other_device') {
        errorDiv.textContent = '❌ This key is already active on another device.';
        errorDiv.classList.remove('hidden');
      } else if (res.status === 'revoked') {
        chrome.storage.sync.set({ hmRevoked: true });
        showRevokedScreen();
      } else if (res.status === 'invalid') {
        errorDiv.textContent = '❌ Invalid key. Please check and try again.';
        errorDiv.classList.remove('hidden');
      } else if (res.status === 'network_error') {
        errorDiv.textContent = '⚠️ No internet. Please try again.';
        errorDiv.classList.remove('hidden');
      } else {
        errorDiv.textContent = '❌ Activation failed. Try again.';
        errorDiv.classList.remove('hidden');
      }
    });
  });
}

// ─── AUTO UPDATE SYSTEM ───────────────────────────────────────────────────────
const CURRENT_VERSION = '1.22.0';
const VERSION_JSON_URL = 'https://raw.githubusercontent.com/helphmmartcenter/hm-schedulex/main/version.json';

function showUpdateBanner(ver, url) {
  if (document.getElementById('hmUpdateBanner')) return;
  const b = document.createElement('div');
  b.id = 'hmUpdateBanner';
  b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:linear-gradient(135deg,#f59e0b,#ef4444);color:white;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;font-family:Segoe UI,sans-serif;font-size:11px;font-weight:700;box-shadow:0 2px 12px rgba(0,0,0,0.3);';
  b.innerHTML = '<span>🆕 New Update v' + ver + ' Available!</span><div style="display:flex;gap:8px;align-items:center;"><button id="hmDlBtn" style="background:white;color:#ef4444;border:none;border-radius:6px;padding:4px 10px;font-size:11px;font-weight:800;cursor:pointer;">Download</button><button id="hmCloseBtn" style="background:transparent;color:white;border:none;font-size:16px;cursor:pointer;">×</button></div>';
  document.body.prepend(b);
  document.getElementById('hmDlBtn').addEventListener('click', () => chrome.tabs.create({ url }));
  document.getElementById('hmCloseBtn').addEventListener('click', () => b.remove());
}

async function checkForUpdate() {
  try {
    const r = await fetch(VERSION_JSON_URL + '?t=' + Date.now());
    const d = await r.json();
    if (d.version && d.version !== CURRENT_VERSION) showUpdateBanner(d.version, d.download_url);
  } catch(e) {}
}

// ─── LICENSE INIT ─────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // License check pehle karo
  checkLicense();

  // Activate button
  document.getElementById('btnActivate').addEventListener('click', () => {
    const key = document.getElementById('licenseKeyInput').value.trim();
    if (key.length !== 9 || !/^\d{9}$/.test(key)) {
      const errorDiv = document.getElementById('licenseError');
      errorDiv.textContent = '❌ Please enter a valid 9-digit key.';
      errorDiv.classList.remove('hidden');
      return;
    }
    handleActivation(key);
  });

  // Enter key support
  document.getElementById('licenseKeyInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('btnActivate').click();
  });
});

const SORT = '&sort=%7B%22columnType%22%3A%22date%22%2C%22sortOrder%22%3A%22DESCENDING%22%7D';
const FILTERS = {
  draft:   'filter=%5B%7B%22name%22%3A%22VISIBILITY%22%2C%22value%22%3A%5B%22DRAFT%22%5D%7D%5D',
  private: 'filter=%5B%7B%22name%22%3A%22VISIBILITY%22%2C%22value%22%3A%5B%22PRIVATE%22%5D%7D%5D'
};
const TYPE_PATH = {
  videos: 'videos/upload',
  shorts: 'videos/short'
};

function getChannelId(url) {
  const m = url.match(/studio\.youtube\.com\/channel\/([^\/\?]+)/);
  return m ? m[1] : null;
}

function buildPageUrl(channelId, type, filter) {
  return `https://studio.youtube.com/channel/${channelId}/${TYPE_PATH[type]}?${FILTERS[filter]}${SORT}`;
}

function addDays(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d;
}

function formatDate(d) {
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
}

// ─── Settings Save/Load ───────────────────────────────────────────────────

function saveSettings(type, filter, total, daily, start, times) {
  chrome.storage.local.set({
    savedSettings: { type, filter, total, daily, start, times }
  });
}

function loadSettings(callback) {
  chrome.storage.local.get(['savedSettings'], (result) => {
    callback(result.savedSettings || null);
  });
}

// ─── History ──────────────────────────────────────────────────────────────

function saveHistory(entry) {
  chrome.storage.local.get(['scheduleHistory'], (result) => {
    const history = result.scheduleHistory || [];
    history.unshift(entry); // Latest first
    // Max 1000 entries
    if (history.length > 1000) history.pop();
    chrome.storage.local.set({ scheduleHistory: history });
  });
}

function loadHistory(callback) {
  chrome.storage.local.get(['scheduleHistory'], (result) => {
    callback(result.scheduleHistory || []);
  });
}

// ─── Main ─────────────────────────────────────────────────────────────────

let selectedType   = null;
let selectedFilter = null;
let scheduleData   = null;

document.addEventListener('DOMContentLoaded', () => {
  const statusDot        = document.getElementById('statusDot');
  const statusText       = document.getElementById('statusText');
  const sectionType      = document.getElementById('sectionType');
  const sectionFilter    = document.getElementById('sectionFilter');
  const sectionForm      = document.getElementById('sectionForm');
  const sectionHistory   = document.getElementById('sectionHistory');
  const sectionLive      = document.getElementById('sectionLive');
  const liveProgressList = document.getElementById('liveProgressList');
  const btnStop          = document.getElementById('btnStopLive');
  const tabSettings      = document.getElementById('tabSettings');
  const tabLive          = document.getElementById('tabLive');
  const panelSettings    = document.getElementById('panelSettings');
  const panelLive        = document.getElementById('panelLive');
  const btnStartSchedule = document.getElementById('btnStartSchedule');
  const liveSummary      = document.getElementById('liveSummary');
  const liveProgressHeader = document.getElementById('liveProgressHeader');
  const introScreen      = document.getElementById('introScreen');
  const btnIntroStart    = document.getElementById('btnIntroStart');

  // ─── Intro Screen — sirf pehli baar install pe ───────────────
  chrome.storage.local.get(['introShown'], (result) => {
    if (!result.introShown) {
      if (introScreen) introScreen.classList.remove('hidden');
      const sb = document.getElementById('statusBar');
      const tb = document.querySelector('.tab-bar');
      if (sb) sb.classList.add('hidden');
      if (tb) tb.classList.add('hidden');
      if (panelSettings) panelSettings.classList.add('hidden');
      if (panelLive) panelLive.classList.add('hidden');
    }
  });

  btnIntroStart.addEventListener('click', () => {
    chrome.storage.local.set({ introShown: true });
    if (introScreen) introScreen.classList.add('hidden');
    const sb = document.getElementById('statusBar');
    const tb = document.querySelector('.tab-bar');
    if (sb) sb.classList.remove('hidden');
    if (tb) tb.classList.remove('hidden');
    if (panelSettings) panelSettings.classList.remove('hidden');
  });
  // ─────────────────────────────────────────────────────────────

  // ─── Tab switching ────────────────────────────────────────────
  function showTab(tab) {
    // History aur Info bhi hide karo
    sectionHistory.classList.add('hidden');
    sectionInfo.classList.add('hidden');

    if (tab === 'settings') {
      panelSettings.classList.remove('hidden');
      panelLive.classList.add('hidden');
      tabSettings.classList.add('active');
      tabLive.classList.remove('active');
      // Sahi section dikhao andar
      if (selectedFilter) {
        sectionType.classList.add('hidden');
        sectionFilter.classList.add('hidden');
        sectionForm.classList.remove('hidden');
      } else if (selectedType) {
        sectionType.classList.add('hidden');
        sectionFilter.classList.remove('hidden');
        sectionForm.classList.add('hidden');
      } else {
        sectionType.classList.remove('hidden');
        sectionFilter.classList.add('hidden');
        sectionForm.classList.add('hidden');
      }
    } else {
      panelSettings.classList.add('hidden');
      panelLive.classList.remove('hidden');
      tabLive.classList.add('active');
      tabSettings.classList.remove('active');
      renderLiveSummary();
    }
  }

  tabSettings.addEventListener('click', () => showTab('settings'));
  tabLive.addEventListener('click',     () => showTab('live'));

  function renderLiveSummary() {
    if (!scheduleData || !liveSummary) return;
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const d = new Date(scheduleData.start);
    const dateStr = `${String(d.getDate()).padStart(2,'0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
    liveSummary.innerHTML = `
      📹 <b>${scheduleData.total}</b> videos &nbsp;|&nbsp; ${scheduleData.type} &nbsp;|&nbsp; ${scheduleData.filter}<br>
      📅 Start: <b>${dateStr}</b> &nbsp;|&nbsp; Daily: <b>${scheduleData.daily}</b><br>
      ⏰ Times: <b>${(scheduleData.times || []).join(', ')}</b>
    `;
    liveSummary.classList.remove('hidden');
  }
  const btnVideos        = document.getElementById('btnVideos');
  const btnShorts        = document.getElementById('btnShorts');
  const btnDraft         = document.getElementById('btnDraft');
  const btnPrivate       = document.getElementById('btnPrivate');
  const btnBackFilter    = document.getElementById('btnBackFilter');
  const btnBackForm      = document.getElementById('btnBackForm');
  const totalVideosEl    = document.getElementById('totalVideos');
  const dailyVideosEl    = document.getElementById('dailyVideos');
  const startDateEl      = document.getElementById('startDate');
  const timesContainer   = document.getElementById('timesContainer');
  const calcBox          = document.getElementById('calcBox');
  const confirmBox       = document.getElementById('confirmBox');
  const btnCalculate     = document.getElementById('btnCalculate');
  const btnConfirmOk     = document.getElementById('btnConfirmOk');
  const btnConfirmNo     = document.getElementById('btnConfirmNo');
  const btnHistoryToggle = document.getElementById('btnHistoryToggle');
  const btnHistoryClose  = document.getElementById('btnHistoryClose');
  const historyList      = document.getElementById('historyList');
  const btnInfoToggle    = document.getElementById('btnInfoToggle');
  const btnInfoClose     = document.getElementById('btnInfoClose');
  const sectionInfo      = document.getElementById('sectionInfo');
  const infoContent      = document.getElementById('infoContent');

  // ─── Check task complete on popup open ──────────────────────────────────
  const taskBanner    = document.getElementById('taskCompleteBanner');
  const taskInfo      = document.getElementById('taskCompleteInfo');
  const btnDismiss    = document.getElementById('btnDismissComplete');

  chrome.storage.local.get(['lastTaskComplete'], (result) => {
    if (result.lastTaskComplete) {
      const { count, time } = result.lastTaskComplete;
      taskInfo.textContent = `${count} video${count !== 1 ? 's' : ''} scheduled — ${time}`;
      taskBanner.classList.remove('hidden');
    }
  });

  btnDismiss.addEventListener('click', () => {
    taskBanner.classList.add('hidden');
    chrome.storage.local.remove('lastTaskComplete');
  });

  // Set today as default start date
  const today = new Date();
  startDateEl.value = today.toISOString().split('T')[0];

  // Detect YouTube Studio tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (tab && tab.url && tab.url.includes('studio.youtube.com')) {
      if (getChannelId(tab.url)) {
        statusDot.classList.add('active');
        statusText.textContent = 'YouTube Studio detected ✓';
      } else {
        statusDot.classList.add('inactive');
        statusText.textContent = 'Channel not detected';
      }
    } else {
      statusDot.classList.add('inactive');
      statusText.textContent = 'Please open YouTube Studio first';
    }
  });

  // ─── Popup open: check scheduling state ──────────────────────────────
  chrome.storage.local.get(['isScheduling', 'liveProgress', 'scheduleData'], (res) => {
    if (res.scheduleData) scheduleData = res.scheduleData;
    if (res.isScheduling) {
      showTab('live');
      btnStartSchedule.classList.add('hidden');
      btnStop.classList.remove('hidden');
      liveProgressHeader.textContent = '⚡ Scheduling in progress...';
      liveProgressHeader.classList.remove('hidden');
      if (res.liveProgress) renderLiveProgress(res.liveProgress);
    }
  });

  // ─── Load saved settings on open ──────────────────────────────────────
  loadSettings((saved) => {
    if (!saved) return;

    // Restore form values first
    if (saved.total) totalVideosEl.value = saved.total;
    if (saved.daily) dailyVideosEl.value = saved.daily;
    if (saved.start) startDateEl.value   = saved.start;

    // Rebuild time fields with saved times
    if (saved.daily) {
      buildTimeFields(saved.times || []);
    }

    // Restore type and filter — show correct section
    // Lekin sirf tab dikhao jab scheduling nahi chal rahi
    chrome.storage.local.get(['isScheduling'], (r) => {
      if (r.isScheduling) return; // Live section already show hai

      if (saved.type && saved.filter) {
        selectedType   = saved.type;
        selectedFilter = saved.filter;
        hide(sectionType);
        hide(sectionFilter);
        show(sectionForm);
      } else if (saved.type) {
        selectedType = saved.type;
        hide(sectionType);
        show(sectionFilter);
      } else {
        show(sectionType);
      }
    });
  });

  // ─── History Toggle ───────────────────────────────────────────────────
  btnHistoryToggle.addEventListener('click', () => {
    panelSettings.classList.add('hidden');
    panelLive.classList.add('hidden');
    sectionInfo.classList.add('hidden');
    sectionHistory.classList.remove('hidden');
    renderHistory();
  });

  btnHistoryClose.addEventListener('click', () => {
    sectionHistory.classList.add('hidden');
    if (panelLive.classList.contains('hidden')) {
      showTab('settings');
    } else {
      showTab('live');
    }
  });

  // ─── Info Panel ───────────────────────────────────────────────
  btnInfoToggle.addEventListener('click', () => {
    panelSettings.classList.add('hidden');
    panelLive.classList.add('hidden');
    sectionHistory.classList.add('hidden');
    sectionInfo.classList.remove('hidden');
    renderInfoTab('howto');
  });

  btnInfoClose.addEventListener('click', () => {
    sectionInfo.classList.add('hidden');
    if (panelLive.classList.contains('hidden')) {
      showTab('settings');
    } else {
      showTab('live');
    }
  });

  // Info tab switching
  document.querySelectorAll('.info-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.info-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderInfoTab(tab.dataset.info);
    });
  });

  function renderInfoTab(tab) {
    infoContent.innerHTML = '';
    if (tab === 'howto')          infoContent.innerHTML = getHowToContent();
    else if (tab === 'changelog') infoContent.innerHTML = getChangelogContent();
    else if (tab === 'about')     infoContent.innerHTML = getAboutContent();
    else if (tab === 'terms')     infoContent.innerHTML = getTermsContent();
    else if (tab === 'privacy')   infoContent.innerHTML = getPrivacyContent();
    else if (tab === 'contact')   infoContent.innerHTML = getContactContent();
  }

  function getContactContent() {
    return `
      <div class="info-section-title">📞 Contact Us</div>

      <div class="info-contact-box">
        <div class="info-contact-row">
          <span class="info-contact-icon">📱</span>
          <div><div class="info-contact-label">WHATSAPP</div><div class="info-contact-value">0328-4070786</div></div>
        </div>
        <div class="info-contact-row">
          <span class="info-contact-icon">📧</span>
          <div><div class="info-contact-label">EMAIL</div><div class="info-contact-value">helphmhamza@gmail.com</div></div>
        </div>
        <div class="info-contact-row">
          <span class="info-contact-icon">🏢</span>
          <div><div class="info-contact-label">COMPANY</div><div class="info-contact-value">HM Mart Center</div></div>
        </div>
        <div class="info-contact-row">
          <span class="info-contact-icon">📍</span>
          <div><div class="info-contact-label">ADDRESS</div><div class="info-contact-value">Smart Point Plaza, Shop #4 (Left Side), Khanpur Maral, Makhdoom Rasheed, Multan, Punjab, Pakistan</div></div>
        </div>
      </div>

      <div class="info-section-title">⏰ Support Hours</div>
      <div class="info-step">
        <div class="info-step-text">We are available for support via WhatsApp and Email. Response time is typically within a few hours during business days.</div>
      </div>

      <div class="info-section-title">🔑 License Issues</div>
      <div class="info-step">
        <div class="info-step-text">If your license is not working, has been accidentally revoked, or you need a new key after changing your device — please contact us on WhatsApp with your previous license key and device details. We will resolve it as soon as possible.</div>
      </div>

      <div class="info-section-title">🐛 Bug Reports & Suggestions</div>
      <div class="info-step">
        <div class="info-step-text">Found a bug or have a feature suggestion? Contact us on WhatsApp or Email with details. We are continuously improving HM ScheduleX based on user feedback.</div>
      </div>
    `;
  }

  function getHowToContent() {
    return `
      <div class="info-section-title">🚀 Getting Started</div>
      <p class="info-text">HM ScheduleX lets you bulk schedule YouTube videos automatically — Draft or Private.</p>

      <div class="info-section-title">🔑 License Activation</div>

      <div class="info-step">
        <div class="info-step-num">Step 1 — Enter Your Key</div>
        <div class="info-step-text">When you first install the extension, a license screen will appear. Enter your 9-digit license key (e.g. 786123456) in the input field.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Step 2 — Click Activate</div>
        <div class="info-step-text">Click the 🔓 Activate button. Your key will be verified online. Once activated, the extension will open automatically — you will never need to enter the key again on the same device.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Step 3 — One Key, One Device</div>
        <div class="info-step-text">Each license key works on one device only. If you reinstall the extension on the same device, your key will work automatically. If you change your device, contact us for support.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Revoked Key</div>
        <div class="info-step-text">If your key is revoked by the administrator, you will see an "Access Revoked" screen. You cannot enter a new key. Contact us at 0328-4070786 for assistance.</div>
      </div>

      <div class="info-section-title">🆕 Auto Update</div>

      <div class="info-step">
        <div class="info-step-num">How it works</div>
        <div class="info-step-text">Every time you open the extension, it automatically checks for a new version in the background.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Update Banner</div>
        <div class="info-step-text">If a new version is available, an orange banner appears at the top: "🆕 New Update vX.X Available!". Click <b>Download</b> to open the download page in a new tab.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">How to Install Update</div>
        <div class="info-step-text">Download the new ZIP file → Go to chrome://extensions → Enable Developer Mode → Click "Load unpacked" → Select the new folder. Your license key and settings will remain saved.</div>
      </div>

      <div class="info-section-title">📍 Schedule Videos — Step-by-Step</div>

      <div class="info-step">
        <div class="info-step-num">Step 1 — Open YouTube Studio</div>
        <div class="info-step-text">Go to studio.youtube.com. The extension shows "YouTube Studio detected ✓" when ready.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Step 2 — Settings Tab</div>
        <div class="info-step-text">Click ⚙️ Settings. Choose content type: <b>Videos</b> or <b>Shorts</b>.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Step 3 — Select Filter</div>
        <div class="info-step-text">Choose <b>Draft</b> (videos saved as draft) or <b>Private</b> (videos set to private visibility).</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Step 4 — Fill Schedule Details</div>
        <div class="info-step-text">
          • <b>Total videos</b> — how many to schedule<br>
          • <b>Videos per day</b> — daily publish count<br>
          • <b>Start date</b> — first publish date<br>
          • <b>Times</b> — publish time for each video per day
        </div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Step 5 — Calculate & Confirm</div>
        <div class="info-step-text">Click ⚡ Calculate to preview the schedule. Review start date, end date, and total days. Click ✅ Save & Go to Live.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">Step 6 — Start Scheduling</div>
        <div class="info-step-text">Go to ⚡ Live tab. Click ✅ Start Scheduling! The extension will automatically process each video one by one.</div>
      </div>

      <div class="info-section-title">📄 Draft Videos Flow</div>
      <p class="info-text">Extension clicks "Edit Draft" → opens editor → Visibility tab → Schedule section → sets date & time → clicks Schedule. Page auto-refreshes every 10 videos.</p>

      <div class="info-section-title">🔒 Private Videos Flow</div>
      <p class="info-text">Extension clicks the "Private" badge → panel opens → Schedule section → sets date & time → clicks Schedule. Page auto-refreshes after each video.</p>

      <div class="info-section-title">⏹ Stop Scheduling</div>
      <p class="info-text">Click the red ⏹ Stop button anytime in the Live tab. The current video will finish and then scheduling stops.</p>

      <div class="info-section-title">📋 History</div>
      <p class="info-text">Click 📋 in the header to view past scheduling sessions — with per-video timestamps, success/fail status, and duration.</p>
    `;
  }

  function getChangelogContent() {
    const versions = [
      { v: '1.22.0', date: '28 March 2026', tag: 'feature', changes: ['How to Use: License Activation guide added', 'How to Use: Auto Update guide added', 'About Us: Professional company info, developer, address', 'Contact Us: Support Hours + License Issues sections added', 'Terms & Conditions: License system section added', 'Privacy Policy: License data storage section added', 'Changelog: Dates added to all versions'] },
      { v: '1.21.0', date: '28 March 2026', tag: 'feature', changes: ['License Key System added — 9-digit key, one device per key', 'Auto Update System — GitHub version check, download banner', 'Revoked key permanent block screen', 'Grace mode for no internet connection'] },
      { v: '1.20.0', date: '28 March 2026', tag: 'feature', changes: ['Info panel added: How to Use, Changelog, About Us, Terms, Privacy, Contact Us', 'History & Info buttons visually distinct', 'Professional Terms & Conditions — 7 sections', 'Professional Privacy Policy — 7 sections'] },
      { v: '1.19.0', date: '28 March 2026', tag: 'feature', changes: ['Introduction screen on first install', 'Shows company info: HM Mart Center, Developer, WhatsApp, Email'] },
      { v: '1.18.0', date: '28 March 2026', tag: 'fix', changes: ['Private video: page refresh after each video', 'Fixed multiple panels opening simultaneously', 'Removed unnecessary popup wait for Private videos', 'Improved panel close logic'] },
      { v: '1.17.0', date: '27 March 2026', tag: 'feature', changes: ['Private video scheduling support added', 'Console-investigated selectors for accurate element detection', 'MouseEvent for browser security bypass'] },
      { v: '1.16.0', date: '27 March 2026', tag: 'fix', changes: ['persistentEntries storage key — entries survive page refresh', 'Fixed live progress clearing after 10-video refresh'] },
      { v: '1.15.0', date: '27 March 2026', tag: 'feature', changes: ['Stop button added in Live tab', 'Popup reopened during scheduling shows progress', 'Real-time progress polling every 1.5 seconds'] },
      { v: '1.14.0', date: '27 March 2026', tag: 'feature', changes: ['Real-time timestamps per video — Start time & Complete time', 'History shows Started and Done clock times'] },
      { v: '1.13.0', date: '27 March 2026', tag: 'fix', changes: ['schedulingRunning lock — prevents double-trigger', 'isScheduling flag stays true during process'] },
      { v: '1.12.0', date: '27 March 2026', tag: 'feature', changes: ['Schedule History panel added', 'Per-session stats: scheduled, failed, remaining', 'Expandable per-video list in history'] },
      { v: '1.11.0', date: '27 March 2026', tag: 'feature', changes: ['Settings auto-save — form values remembered', 'Saved settings restored on popup open'] },
      { v: '1.10.0', date: '27 March 2026', tag: 'feature', changes: ['Live tab added with real-time progress', 'Settings and Live tabs separated', 'Start Scheduling button in Live tab'] },
      { v: '1.9.0', date: '26 March 2026', tag: 'fix', changes: ['Date input validation improved', 'Invalid dates auto-corrected to last valid day of month'] },
      { v: '1.8.0', date: '26 March 2026', tag: 'feature', changes: ['Retry logic — max 3 attempts per video', 'Date & time re-set on retry'] },
      { v: '1.7.0', date: '26 March 2026', tag: 'fix', changes: ['Time dropdown — nearest 15-min slot selection', 'Time input fallback with native setter'] },
      { v: '1.6.0', date: '26 March 2026', tag: 'fix', changes: ['Date input — character-by-character typing', 'Date format detection: UK vs US format'] },
      { v: '1.5.0', date: '26 March 2026', tag: 'feature', changes: ['Unlimited videos — no 50 video cap', 'Page auto-refresh every 10 videos'] },
      { v: '1.4.0', date: '25 March 2026', tag: 'feature', changes: ['Task Complete banner after scheduling', 'Session duration and average time per video'] },
      { v: '1.3.0', date: '25 March 2026', tag: 'fix', changes: ['Schedule section expand — multiple detection methods', 'Visibility tab detection improved'] },
      { v: '1.2.0', date: '25 March 2026', tag: 'fix', changes: ['Already-scheduled video detection — skip logic', 'Next page navigation improved'] },
      { v: '1.1.0', date: '24 March 2026', tag: 'feature', changes: ['Multi-tab support', 'Channel ID detection from URL', 'Filter URLs for Draft and Private'] },
      { v: '1.0.0', date: '24 March 2026', tag: 'new', changes: ['Initial release', 'Bulk schedule YouTube Draft videos', 'Date, time, daily count configuration', 'Progress tracking in popup'] },
    ];

    return versions.map(item => `
      <div class="changelog-item">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
          <span class="changelog-version">v${item.v}</span>
          <span class="changelog-tag tag-${item.tag}">${item.tag === 'new' ? '🆕 NEW' : item.tag === 'fix' ? '🔧 FIX' : '⭐ FEATURE'}</span>
          <span style="font-size:10px;color:#888;">${item.date}</span>
        </div>
        <ul class="changelog-list">
          ${item.changes.map(c => `<li>${c}</li>`).join('')}
        </ul>
      </div>
    `).join('');
  }

  function getAboutContent() {
    return `
      <div class="info-section-title">🏢 About HM ScheduleX</div>
      <p class="info-text">HM ScheduleX is a professional Chrome Extension that automates bulk scheduling of YouTube videos — both Draft and Private — directly from YouTube Studio. Development started on <b>24 March 2026</b> and officially launched on <b>28 March 2026</b>. It was built to help YouTube creators save time and scale their content publishing efficiently.</p>

      <div class="info-section-title">👤 Developer & CEO</div>
      <div class="info-contact-box">
        <div class="info-contact-row">
          <span class="info-contact-icon">👤</span>
          <div><div class="info-contact-label">DEVELOPER & CEO</div><div class="info-contact-value">M. Ameer Hamza</div></div>
        </div>
        <div class="info-contact-row">
          <span class="info-contact-icon">🏢</span>
          <div><div class="info-contact-label">COMPANY</div><div class="info-contact-value">HM Mart Center</div></div>
        </div>
        <div class="info-contact-row">
          <span class="info-contact-icon">📍</span>
          <div><div class="info-contact-label">ADDRESS</div><div class="info-contact-value">Smart Point Plaza, Shop #4 (Left Side), Khanpur Maral, Makhdoom Rasheed, Multan, Punjab, Pakistan</div></div>
        </div>
        <div class="info-contact-row">
          <span class="info-contact-icon">📱</span>
          <div><div class="info-contact-label">WHATSAPP</div><div class="info-contact-value">0328-4070786</div></div>
        </div>
        <div class="info-contact-row">
          <span class="info-contact-icon">📧</span>
          <div><div class="info-contact-label">EMAIL</div><div class="info-contact-value">helphmhamza@gmail.com</div></div>
        </div>
      </div>

      <div class="info-section-title">🚀 About This Extension</div>
      <p class="info-text">HM ScheduleX handles automatic scheduling of Draft and Private YouTube videos with full control over dates, times, and daily publish counts. It runs directly in YouTube Studio — no separate app needed. Features include real-time progress tracking, scheduling history, license protection, and auto update system.</p>
    `;
  }

  function getTermsContent() {
    return `
      <div class="info-section-title">📜 Terms &amp; Conditions</div>
      <p class="info-text" style="color:#888;font-size:10px;">Last Updated: 28 March 2026</p>

      <div class="info-step">
        <div class="info-step-num">1. Acceptance of Terms</div>
        <div class="info-step-text">By installing and using HM ScheduleX, you agree to be bound by these Terms and Conditions. If you do not agree, please uninstall the extension immediately.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">2. License Key</div>
        <div class="info-step-text">Each license key is issued for use on one device only. Sharing, reselling, or transferring your license key to another person is strictly prohibited. HM Mart Center reserves the right to revoke any key without prior notice if misuse is detected.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">3. License</div>
        <div class="info-step-text">HM Mart Center grants you a non-exclusive, non-transferable, limited license to use this extension for personal or professional YouTube content scheduling. You may not copy, modify, distribute, sell, or lease any part of the extension without written permission.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">4. User Responsibilities</div>
        <div class="info-step-text">You are solely responsible for ensuring your use complies with YouTube's Terms of Service and Community Guidelines. You must not schedule spam, misleading, or prohibited content.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">5. Prohibited Uses</div>
        <div class="info-step-text">You may not: violate any law, infringe intellectual property rights, attempt to reverse-engineer the extension, or resell/redistribute without authorization.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">6. Disclaimer of Warranties</div>
        <div class="info-step-text">This extension is provided "as is". HM Mart Center does not guarantee uninterrupted operation. YouTube may change its interface at any time which could temporarily affect functionality.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">7. Limitation of Liability</div>
        <div class="info-step-text">HM Mart Center shall not be liable for any damages arising from use of this extension, including account actions taken by YouTube, data loss, or scheduling errors.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">8. Changes to Terms</div>
        <div class="info-step-text">We reserve the right to modify these terms at any time. Continued use constitutes acceptance of new terms.</div>
      </div>

      <p class="info-text" style="margin-top:8px;"><b>Contact:</b> helphmhamza@gmail.com | WhatsApp: 0328-4070786</p>
    `;
  }

  function getPrivacyContent() {
    return `
      <div class="info-section-title">🔒 Privacy Policy</div>
      <p class="info-text" style="color:#888;font-size:10px;">Last Updated: 28 March 2026</p>

      <div class="info-step">
        <div class="info-step-num">1. Introduction</div>
        <div class="info-step-text">HM Mart Center is committed to protecting your privacy. This policy explains how HM ScheduleX handles your information.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">2. Data We Do NOT Collect</div>
        <div class="info-step-text">We do not collect, store, transmit, or share any personal data with external servers. We do not track browsing activity, collect YouTube credentials, use analytics, or share data with third parties.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">3. License Data (chrome.storage.sync)</div>
        <div class="info-step-text">Your license key, activation status, device ID, and revoke status are stored in chrome.storage.sync. This data is synced to your Google account securely and is used only to verify your license. It survives extension reinstall on the same device.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">4. Local Data (chrome.storage.local)</div>
        <div class="info-step-text">Schedule settings, history, progress, and preferences are stored locally on your device only. This data never leaves your device and is cleared when you uninstall the extension.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">5. License Verification</div>
        <div class="info-step-text">When activating or verifying your license, your key and device ID are sent to our Google Apps Script API for verification. No other personal information is sent. The API is used solely for license management.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">6. YouTube Studio Access</div>
        <div class="info-step-text">This extension operates on studio.youtube.com to automate scheduling. It does not access, read, or store your YouTube credentials, account information, or video content.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">7. Permissions Used</div>
        <div class="info-step-text">activeTab: detect current tab. storage: save settings. tabs: navigate to YouTube Studio. scripting: interact with YouTube Studio elements. These are used solely for scheduling functionality.</div>
      </div>

      <div class="info-step">
        <div class="info-step-num">8. Changes to This Policy</div>
        <div class="info-step-text">We may update this Privacy Policy from time to time. Updates will be reflected in the extension's changelog.</div>
      </div>

      <p class="info-text" style="margin-top:8px;"><b>Contact:</b> helphmhamza@gmail.com | WhatsApp: 0328-4070786</p>
    `;
  }

  function renderHistory() {
    loadHistory((history) => {
      historyList.innerHTML = '';

      if (history.length === 0) {
        historyList.innerHTML = '<p class="history-empty">📭 No history yet.</p>';
        return;
      }

      // Overall stats
      const totalSched = history.reduce((s,e) => s + (parseInt(e.scheduled || e.total) || 0), 0);
      const totalFail  = history.reduce((s,e) => s + (parseInt(e.failed) || 0), 0);
      const today = new Date().toDateString();

      const statsDiv = document.createElement('div');
      statsDiv.className = 'history-stats';
      statsDiv.innerHTML = `
        <div class="stat-item"><b>${totalSched}</b><span>Total</span></div>
        <div class="stat-item"><b>${totalFail}</b><span>Failed</span></div>
        <div class="stat-item"><b>${history.length}</b><span>Sessions</span></div>
      `;
      historyList.appendChild(statsDiv);

      // Clear button
      const clearBtn = document.createElement('button');
      clearBtn.className = 'btn-clear-history';
      clearBtn.textContent = '🗑️ Clear History';
      clearBtn.addEventListener('click', () => {
        chrome.storage.local.set({ scheduleHistory: [] }, renderHistory);
      });
      historyList.appendChild(clearBtn);

      // Session entries
      history.forEach((entry) => {
        const card = document.createElement('div');
        card.className = 'history-item';

        const sched    = parseInt(entry.scheduled ?? entry.total) || 0;
        const failed   = parseInt(entry.failed) || 0;
        const remain   = parseInt(entry.remaining) || 0;
        const avg      = entry.avgSecPerVideo || 0;
        const duration = entry.sessionDuration || 0;
        const durStr   = duration > 60
          ? `${Math.floor(duration/60)}m ${duration%60}s`
          : `${duration}s`;

        card.innerHTML = `
          <div class="history-date">🕐 ${entry.date}</div>
          ${entry.sessionStart ? `<div class="history-sub">▶️ Started: ${entry.sessionStart} &nbsp;|&nbsp; ⏱ Duration: ${durStr}</div>` : ''}
          ${avg > 0 ? `<div class="history-sub">⚡ Avg: ${avg}s per video</div>` : ''}
          <div class="history-info">📹 <b>${entry.total}</b> videos &nbsp;|&nbsp; ${entry.type} &nbsp;|&nbsp; ${entry.filter}</div>
          <div class="history-info">📅 ${entry.startDate} → ${entry.endDate} &nbsp;|&nbsp; Daily: ${entry.daily}</div>
          <div class="history-stats-mini">
            <span class="stat-ok">✅ ${sched} scheduled</span>
            <span class="stat-fail">❌ ${failed} failed</span>
            ${remain > 0 ? `<span class="stat-rem">⏳ ${remain} remaining</span>` : ''}
          </div>
        `;

        // Expandable video list
        if (entry.videoEntries && entry.videoEntries.length > 0) {
          const toggleBtn = document.createElement('button');
          toggleBtn.className = 'btn-toggle-videos';
          toggleBtn.textContent = `▼ Show ${entry.videoEntries.length} videos`;
          toggleBtn.dataset.expanded = 'false';

          const videoList = document.createElement('div');
          videoList.className = 'video-entry-list hidden';

          // Failed first
          const failedVids = entry.videoEntries.filter(v => !v.success);
          if (failedVids.length > 0) {
            const fh = document.createElement('div');
            fh.style.cssText = 'color:#ff5252;font-size:11px;font-weight:700;padding:3px 0;';
            fh.textContent = `❌ Failed (${failedVids.length}):`;
            videoList.appendChild(fh);
            failedVids.forEach(v => {
              const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
              const d = new Date(v.date);
              const ds = isNaN(d) ? v.date : `${String(d.getDate()).padStart(2,'0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
              const el = document.createElement('div');
              el.className = 'video-entry-item';
              el.style.color = '#ff5252';
              el.innerHTML = `❌ Video ${v.videoNum} — ${ds} | ${v.time}${v.attempts > 1 ? ' ('+v.attempts+' tries)' : ''}`;
              videoList.appendChild(el);
            });
            const div = document.createElement('div');
            div.style.cssText = 'border-top:1px solid #333;margin:3px 0;';
            videoList.appendChild(div);
          }

          // All videos
          entry.videoEntries.forEach((v, i) => {
            const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            const d = new Date(v.date);
            const ds = isNaN(d) ? v.date : `${String(d.getDate()).padStart(2,'0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
            const el = document.createElement('div');
            el.className = 'video-entry-item';
            const tsLine = (v.startedAt || v.completedAt)
              ? `<span style="color:#888;font-size:10px;display:block;padding-left:18px;">▶ ${v.startedAt || '—'} &nbsp; ✅ ${v.completedAt || '—'}</span>`
              : '';
            el.innerHTML = `${v.success ? '✅' : '❌'} Video ${i+1} — ${ds} | ${v.time}${v.timeTaken ? ' <span style="color:#888">('+v.timeTaken+'s)</span>' : ''}${tsLine}`;
            videoList.appendChild(el);
          });

          toggleBtn.addEventListener('click', () => {
            const exp = toggleBtn.dataset.expanded === 'true';
            videoList.classList.toggle('hidden', exp);
            toggleBtn.textContent = exp
              ? `▼ Show ${entry.videoEntries.length} videos`
              : `▲ Hide videos`;
            toggleBtn.dataset.expanded = (!exp).toString();
          });

          card.appendChild(toggleBtn);
          card.appendChild(videoList);
        }

        historyList.appendChild(card);
      });
    });
  }


  // Step 1: Type
  btnVideos.addEventListener('click', () => {
    selectedType = 'videos';
    show(sectionFilter); hide(sectionType);
    autoSaveSettings();
  });
  btnShorts.addEventListener('click', () => {
    selectedType = 'shorts';
    show(sectionFilter); hide(sectionType);
    autoSaveSettings();
  });

  // Back: Filter → Type
  btnBackFilter.addEventListener('click', () => {
    selectedType = null;
    show(sectionType); hide(sectionFilter);
    autoSaveSettings();
  });

  // Step 2: Filter
  btnDraft.addEventListener('click', () => {
    selectedFilter = 'draft';
    show(sectionForm); hide(sectionFilter);
    buildTimeFields();
    autoSaveSettings();
  });
  btnPrivate.addEventListener('click', () => {
    selectedFilter = 'private';
    show(sectionForm); hide(sectionFilter);
    buildTimeFields();
    autoSaveSettings();
  });

  // Back: Form → Filter
  btnBackForm.addEventListener('click', () => {
    selectedFilter = null;
    show(sectionFilter); hide(sectionForm);
    resetCalc();
    autoSaveSettings();
  });

  // Auto save on input change
  dailyVideosEl.addEventListener('input', () => {
    buildTimeFields();
    resetCalc();
    autoSaveSettings();
  });
  totalVideosEl.addEventListener('input', () => { resetCalc(); autoSaveSettings(); });
  startDateEl.addEventListener('input', () => {
    // Validate date — har month ke sahi days check karo
    const val = startDateEl.value; // "YYYY-MM-DD"
    if (val) {
      const d = new Date(val);
      // Agar date invalid hai (e.g. Feb 31) — browser "" return karta hai
      if (isNaN(d.getTime()) || startDateEl.validity.badInput) {
        startDateEl.style.borderColor = '#ff4444';
      } else {
        startDateEl.style.borderColor = '';
        // Double check: month ke max days
        const [year, month, day] = val.split('-').map(Number);
        const maxDay = new Date(year, month, 0).getDate(); // month ke last din
        if (day > maxDay) {
          // Auto-correct to last valid day of month
          startDateEl.value = `${year}-${String(month).padStart(2,'0')}-${String(maxDay).padStart(2,'0')}`;
        }
      }
    }
    resetCalc();
    autoSaveSettings();
  });

  function autoSaveSettings() {
    const times = Array.from(document.querySelectorAll('.time-input')).map(t => t.value);
    saveSettings(
      selectedType,
      selectedFilter,
      totalVideosEl.value,
      dailyVideosEl.value,
      startDateEl.value,
      times
    );
  }

  function buildTimeFields(savedTimes = []) {
    timesContainer.innerHTML = '';
    const daily = parseInt(dailyVideosEl.value) || 0;
    for (let i = 0; i < daily; i++) {
      const row = document.createElement('div');
      row.className = 'time-row';
      const lbl = document.createElement('span');
      lbl.className = 'time-label';
      lbl.textContent = `Video ${i + 1}:`;
      const inp = document.createElement('input');
      inp.type = 'time';
      inp.className = 'time-input';
      // Saved time use karo, nahi to default
      inp.value = savedTimes[i] || (i === 0 ? '07:00' : i === 1 ? '09:00' : '10:00');
      inp.addEventListener('change', autoSaveSettings);
      row.appendChild(lbl);
      row.appendChild(inp);
      timesContainer.appendChild(row);
    }
  }

  // Calculate button
  btnCalculate.addEventListener('click', () => {
    const total = parseInt(totalVideosEl.value);
    const daily = parseInt(dailyVideosEl.value);
    const start = startDateEl.value;
    const times = Array.from(document.querySelectorAll('.time-input'));

    if (!total || total < 1) {
      showCalc('error', '⚠️ Total videos must be at least 1!'); return;
    }
    if (!daily || daily < 1 || daily > total) {
      showCalc('error', '⚠️ Daily videos count is invalid!'); return;
    }
    if (!start) {
      showCalc('error', '⚠️ Please select a start date!'); return;
    }
    if (times.length !== daily) {
      showCalc('error', '⚠️ Please set daily videos count first!'); return;
    }
    for (let t of times) {
      if (!t.value) { showCalc('error', '⚠️ All times are required!'); return; }
    }

    const daysNeeded = Math.ceil(total / daily);
    const endDate    = addDays(start, daysNeeded - 1);

    scheduleData = {
      total, daily, start,
      daysNeeded,
      endDate: endDate.toISOString().split('T')[0],
      times: times.map(t => t.value),
      type: selectedType,
      filter: selectedFilter
    };

    showCalc('success',
      `✅ ${total} videos — ${daily} per day\n` +
      `📅 Start: ${formatDate(new Date(start))}\n` +
      `📅 End: ${formatDate(endDate)}\n` +
      `🗓️ Total days: ${daysNeeded}`
    );
    show(confirmBox);
  });

  // Save & Go to Live tab
  btnConfirmOk.addEventListener('click', () => {
    // scheduleData storage mein save karo
    chrome.storage.local.set({ scheduleData: scheduleData }, () => {
      // Live tab pe jaao
      showTab('live');
    });
  });

  // ─── Start Scheduling button (Live tab) ───────────────────────
  btnStartSchedule.addEventListener('click', () => {
    if (!scheduleData) {
      alert('Pehle Settings tab mein details fill karo!');
      showTab('settings');
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      const cId = getChannelId(tab.url || '');

      if (!cId) {
        alert('Please open YouTube Studio first!');
        return;
      }

      const pageUrl = buildPageUrl(cId, selectedType, selectedFilter);

      // TURANT Start → Stop banana
      btnStartSchedule.classList.add('hidden');
      btnStop.classList.remove('hidden');

      // Progress header show karo
      liveProgressHeader.textContent = `⚡ Scheduling ${scheduleData.total} videos...`;
      liveProgressHeader.classList.remove('hidden');

      // liveProgressList clear karo
      if (liveProgressList) liveProgressList.innerHTML = '';

      // Storage mein save karo
      chrome.storage.local.set({
        scheduleData: { ...scheduleData, processedOffset: 0 },
        isScheduling: true,
        schedulingStopped: false,
        liveProgress: null
      }, () => {
        chrome.tabs.update(tab.id, { url: pageUrl });
      });
    });
  });

  // Edit button
  btnConfirmNo.addEventListener('click', resetCalc);

  // Helpers
  function show(el) { el.classList.remove('hidden'); }
  function hide(el) { el.classList.add('hidden'); }

  function showCalc(type, msg) {
    calcBox.className = `calc-box ${type}`;
    calcBox.style.whiteSpace = 'pre-line';
    calcBox.textContent = msg;
  }

  function resetCalc() {
    calcBox.className = 'calc-box hidden';
    calcBox.textContent = '';
    hide(confirmBox);
    scheduleData = null;
  }

  // ─── Pause / Resume / Stop ────────────────────────────────────────────
  // Pause/Resume removed — sirf Stop hai

  btnStop.addEventListener('click', () => {
    chrome.storage.local.set({ 
      isScheduling: false,
      schedulingStopped: true,
      schedulePaused: false
    });
    // Stop button → Start banana
    btnStop.classList.add('hidden');
    btnStartSchedule.classList.remove('hidden');
    liveProgressHeader.textContent = '⏹ Stopped';
    console.log('[HM ScheduleX Popup] Stopped');
  });

  // ─── Live Progress Listener ────────────────────────────────────────────
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.liveProgress) {
      const progress = changes.liveProgress.newValue;
      if (progress) {
        renderLiveProgress(progress);
        // Sirf tab Start wapas dikhao jab sab videos complete ho jayein
        if (progress.processed >= progress.total && progress.total > 0) {
          btnStop.classList.add('hidden');
          btnStartSchedule.classList.remove('hidden');
        }
      }
    }
    // isScheduling false pe kuch mat karo — page refresh bhi false karta hai
  });

  // (scheduling check moved to top)

  function renderLiveProgress(progress) {
    if (!liveProgressList) return;
    liveProgressList.innerHTML = '';

    // Progress count header
    const header = document.createElement('div');
    header.className = 'live-header';
    header.textContent = `📊 ${progress.processed}/${progress.total} videos`;
    liveProgressList.appendChild(header);

    // Progress bar
    const barWrap = document.createElement('div');
    barWrap.className = 'progress-bar-wrap';
    const bar = document.createElement('div');
    bar.className = 'progress-bar-fill';
    const pct = Math.round((progress.processed / progress.total) * 100);
    bar.style.width = pct + '%';
    bar.textContent = pct + '%';
    barWrap.appendChild(bar);
    liveProgressList.appendChild(barWrap);

    // Current status — jo abhi ho raha hai
    if (progress.currentStatus) {
      const statusDiv = document.createElement('div');
      statusDiv.style.cssText = 'font-size:12px;color:#ffb74d;padding:4px 2px;font-style:italic;';
      statusDiv.textContent = progress.currentStatus;
      liveProgressList.appendChild(statusDiv);
    }

    // Individual video entries — newest first
    const entries = progress.entries || [];
    entries.slice().reverse().forEach(entry => {
      const div = document.createElement('div');
      div.className = 'live-entry';
      // Date format: YYYY-MM-DD → readable
      const d = new Date(entry.date);
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      const dateStr = `${String(d.getDate()).padStart(2,'0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
      const timeLine = (entry.startedAt || entry.completedAt)
        ? `<span class="live-timestamps">▶ ${entry.startedAt || '—'} &nbsp;✅ ${entry.completedAt || '—'}</span>`
        : '';
      div.innerHTML = `
        <span class="live-icon">${entry.success ? '✅' : '❌'}</span>
        <span class="live-detail">
          ${dateStr} | ${entry.time} — <span class="live-status">${entry.success ? 'Scheduled' : 'Failed'}</span>
          ${timeLine}
        </span>`;
      liveProgressList.appendChild(div);
    });
  }

  buildTimeFields();
});
