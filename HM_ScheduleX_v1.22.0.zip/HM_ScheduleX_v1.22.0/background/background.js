// HM ScheduleX - Background Service Worker
// Version: 1.22.0

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('[HM ScheduleX] Extension install ho gayi! Version: 1.22.0');
    // Fresh install — intro screen dikhane ke liye flag clear karo
    chrome.storage.local.remove('introShown');
  } else if (details.reason === 'update') {
    console.log('[HM ScheduleX] Extension update ho gayi! Version:', chrome.runtime.getManifest().version);
  }
});
