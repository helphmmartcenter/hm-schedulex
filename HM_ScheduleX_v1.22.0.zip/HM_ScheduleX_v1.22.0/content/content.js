// HM ScheduleX - Content Script
// Version: 1.22.0
// Runs on: studio.youtube.com

console.log('[HM ScheduleX v1.22.0] Content script loaded.');

// Lock — double trigger rokne ke liye (page load + MutationObserver dono fire karte hain)
let schedulingRunning = false;

// Check on page load
window.addEventListener('load', () => {
  setTimeout(checkAndStartScheduling, 3000);
});

// Check on URL change (YouTube Studio is SPA)
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    setTimeout(checkAndStartScheduling, 3000);
  }
}).observe(document, { subtree: true, childList: true });

async function checkAndStartScheduling() {
  try {
    chrome.storage.local.get(['scheduleData', 'isScheduling'], (result) => {
      if (chrome.runtime.lastError) {
        console.warn('[HM ScheduleX] Storage error:', chrome.runtime.lastError.message);
        return;
      }
      if (result.isScheduling && result.scheduleData) {
        // schedulingRunning lock — double trigger rokta hai
        // isScheduling storage mein TRUE rehta hai — popup status track karne ke liye
        if (schedulingRunning) {
          console.log('[HM ScheduleX] Already running — skip.');
          return;
        }
        console.log('[HM ScheduleX] Scheduling mode ON!');
        schedulingRunning = true;
        startScheduling(result.scheduleData);
      }
    });
  } catch (e) {
    console.warn('[HM ScheduleX] Extension context error:', e.message);
  }
}

// ─── Main Scheduling Function ─────────────────────────────────────────────

function getLiveProgressData(processed, total, entries) {
  return { processed, total, entries: entries || [] };
}

function sendLiveStatus(processed, total, entries, statusMsg) {
  // Current video ka status popup mein dikhao
  chrome.storage.local.set({
    liveProgress: {
      processed, total,
      entries: entries || [],
      currentStatus: statusMsg
    }
  });
}

async function startScheduling(scheduleData) {
  console.log('[HM ScheduleX] Starting...', scheduleData);
  const totalVideos = scheduleData.total;
  const dailyVideos = scheduleData.daily;
  const startDate   = scheduleData.start; // "YYYY-MM-DD"
  // processedOffset — page refresh ke baad yahan se shuru karo
  const processedOffset = scheduleData.processedOffset || 0;
  let processed = processedOffset;
  const sessionStartTime = Date.now(); // session start time

  // Page refresh ke baad entries dedicated key se load karo
  // persistentEntries sirf entries save karta hai — liveProgress se alag
  // Agar fresh start hai (processedOffset === 0) toh entries clear karo
  if (processedOffset === 0) {
    await new Promise(resolve => chrome.storage.local.set({ persistentEntries: [] }, resolve));
  }
  const savedEntries = await new Promise(resolve =>
    chrome.storage.local.get(['persistentEntries'], r => resolve(r.persistentEntries || []))
  );
  let liveEntries = savedEntries;
  console.log(`[HM ScheduleX] Starting from video ${processed + 1}/${totalVideos} | Loaded ${liveEntries.length} previous entries`);

  while (processed < totalVideos) {
    await wait(2000);

    // Har 10 video ke baad page refresh — sirf Draft ke liye
    // Private mein har video ke baad refresh hota hai (neeche)
    if (scheduleData.filter !== 'private' && processed > 0 && processed % 10 === 0 && processed > processedOffset) {
      console.log(`[HM ScheduleX] ${processed} videos done — page refresh kar raha hun...`);
      await new Promise(resolve => {
        chrome.storage.local.set({
          isScheduling: true,
          scheduleData: { ...scheduleData, processedOffset: processed },
          liveProgress: getLiveProgressData(processed, scheduleData.total, liveEntries)
        }, resolve);
      });
      const channelId = location.href.match(/channel\/([^\/\?]+)/)?.[1];
      const type = scheduleData.type === 'shorts' ? 'videos/short' : 'videos/upload';
      const filterParam = 'filter=%5B%7B%22name%22%3A%22VISIBILITY%22%2C%22value%22%3A%5B%22DRAFT%22%5D%7D%5D';
      const sort = '&sort=%7B%22columnType%22%3A%22date%22%2C%22sortOrder%22%3A%22DESCENDING%22%7D';
      const refreshUrl = `https://studio.youtube.com/channel/${channelId}/${type}?${filterParam}${sort}`;
      location.href = refreshUrl;
      return;
    }

    // Stop check — agar user ne Stop click kiya toh band karo
    const stopCheck = await new Promise(resolve => {
      chrome.storage.local.get(['schedulingStopped'], r => resolve(r.schedulingStopped));
    });
    if (stopCheck) {
      console.log('[HM ScheduleX] Stop detected — scheduling band kar raha hun');
      schedulingRunning = false;
      chrome.storage.local.set({ schedulingStopped: false, isScheduling: false });
      return;
    }

    // Fresh buttons dhundo har iteration mein — filter ke hisaab se
    let editBtns = [];
    if (scheduleData.filter === 'private') {
      editBtns = await waitForPrivateVideoBadges();
    } else {
      editBtns = await waitForEditDraftButtons();
    }

    if (!editBtns || editBtns.length === 0) {
      console.warn('[HM ScheduleX] No video items found!');
      break;
    }

    console.log(`[HM ScheduleX] Found ${editBtns.length} video items`);

    // Sirf pehla unprocessed button process karo — phir loop restart
    let processedInThisRound = false;

    for (let btnIndex = 0; btnIndex < editBtns.length; btnIndex++) {
      const btn = editBtns[btnIndex];
      if (processed >= totalVideos) break;

      // Calculate date and time for this video
      const videoDate = getVideoDate(startDate, processed, dailyVideos);
      const timeIndex = processed % dailyVideos;
      const videoTime = scheduleData.times[timeIndex] || '07:00';
      console.log(`[HM ScheduleX] Video ${processed + 1}: Date → ${videoDate} | Time → ${videoTime}`);

      // Pehle check karo — kya yeh button abhi bhi Draft hai (Schedule nahi)
      const row = btn.closest('tr, ytcp-video-row, div[class*="row"]') || btn.parentElement;
      if (row) {
        const rowText = (row.innerText || row.textContent || '').toLowerCase();
        if (rowText.includes('scheduled') && !rowText.includes('edit draft')) {
          console.log(`[HM ScheduleX] Video ${processed + 1}: Already scheduled, skipping...`);
          processed++;
          continue;
        }
      }

      // Step 1: Click to open scheduling dialog
      const videoStartTime = Date.now();
      const videoStartedAt = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

      if (scheduleData.filter === 'private') {
        // Private flow: Click "Private" badge → panel opens with Schedule section
        console.log(`[HM ScheduleX] Video ${processed + 1}: Clicking Private badge...`);
        sendLiveStatus(processed, totalVideos, liveEntries, `⏳ Video ${processed+1} — Opening Private video...`);

        // Pehle koi bhi open panel band karo — multiple panels problem fix
        await closePrivatePanel();
        await wait(500);

        // Proper MouseEvent — browser security bypass ke liye
        btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        await wait(100);
        btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        await wait(100);
        btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        await wait(2500); // Panel fully open hone ka wait

        // Panel khul gaya — p#visibility-title "Schedule" pe click karo
        // expandScheduleSection wait karega jab tak "Schedule" text visible na ho
        const scheduleExpanded = await expandScheduleSection();
        console.log(`[HM ScheduleX] Video ${processed + 1}: Schedule section ${scheduleExpanded ? '✓' : '✗'}`);

        if (!scheduleExpanded) {
          console.warn(`[HM ScheduleX] Video ${processed + 1}: Schedule section nahi mila — skip`);
          document.body.click();
          await wait(1000);
          processed++;
          continue;
        }

        await wait(1000);
        // Date set karo
        sendLiveStatus(processed, totalVideos, liveEntries, `⏳ Video ${processed+1} — Setting date & time...`);

        const dateSet = await selectScheduleDate(videoDate);
        console.log(`[HM ScheduleX] Video ${processed + 1}: Date set ${dateSet ? '✓' : '✗'}`);

        await wait(800);
        const timeSet = await setScheduleTime(videoTime);
        console.log(`[HM ScheduleX] Video ${processed + 1}: Time set ${timeSet ? '✓' : '✗'}`);

        sendLiveStatus(processed, totalVideos, liveEntries, `⏳ Video ${processed+1} — Clicking Schedule...`);
        await wait(1000);
        let scheduled = false;
        let attempt = 0;
        const maxAttempts = 3;

        while (!scheduled && attempt < maxAttempts) {
          attempt++;
          if (attempt > 1) {
            await wait(2000);
            await selectScheduleDate(videoDate);
            await wait(800);
            await setScheduleTime(videoTime);
            await wait(1000);
          }
          scheduled = await clickScheduleButton();
          console.log(`[HM ScheduleX] Video ${processed + 1}: Attempt ${attempt} — Scheduled ${scheduled ? '✓' : '✗'}`);
          if (scheduled) {
            // Private mein koi popup nahi aata — seedha wait karo
            await wait(3000);
          }
        }

        if (!scheduled) {
          console.warn(`[HM ScheduleX] Video ${processed + 1}: ${maxAttempts} attempts ke baad bhi fail`);
          // Panel band karo — Cancel button ya Escape
          await closePrivatePanel();
          await wait(2000);
        } else {
          // Scheduled hone ke baad panel automatically band ho jaata hai
          // Lekin agar nahi hua toh force close karo
          await wait(1000);
          await closePrivatePanel();
          await wait(1500);
        }

        // Entry add karo
        const videoTimeTaken = Math.round((Date.now() - videoStartTime) / 1000);
        const videoCompletedAt = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
        liveEntries.push({
          videoNum: processed + 1,
          date: videoDate,
          time: videoTime,
          success: scheduled,
          attempts: attempt,
          timeTaken: videoTimeTaken,
          startedAt: videoStartedAt,
          completedAt: videoCompletedAt
        });

        processed++;
        processedInThisRound = true;
        console.log(`[HM ScheduleX] Progress: ${processed}/${totalVideos} | ${scheduled ? 'OK' : 'FAILED'}`);

        // Storage update karo
        await new Promise(resolve => {
          chrome.storage.local.set({
            liveProgress: getLiveProgressData(processed, totalVideos, liveEntries),
            persistentEntries: liveEntries
          }, resolve);
        });

        // Private mein har video ke baad page refresh — scheduled video list se hat jaati hai
        if (processed < totalVideos) {
          console.log(`[HM ScheduleX] Private: page refresh kar raha hun...`);
          await new Promise(resolve => {
            chrome.storage.local.set({
              isScheduling: true,
              scheduleData: { ...scheduleData, processedOffset: processed },
            }, resolve);
          });
          const channelId = location.href.match(/channel\/([^\/\?]+)/)?.[1];
          const type = scheduleData.type === 'shorts' ? 'videos/short' : 'videos/upload';
          const filterParam = 'filter=%5B%7B%22name%22%3A%22VISIBILITY%22%2C%22value%22%3A%5B%22PRIVATE%22%5D%7D%5D';
          const sort = '&sort=%7B%22columnType%22%3A%22date%22%2C%22sortOrder%22%3A%22DESCENDING%22%7D';
          const refreshUrl = `https://studio.youtube.com/channel/${channelId}/${type}?${filterParam}${sort}`;
          location.href = refreshUrl;
          return;
        }
        break;

      } else {
        // ── Draft flow (unchanged) ──
        console.log(`[HM ScheduleX] Video ${processed + 1}: Clicking Edit draft...`);
        sendLiveStatus(processed, totalVideos, liveEntries, `⏳ Video ${processed+1} — Opening draft...`);
        btn.click();

      // Step 2: Wait for dialog → Click Visibility tab
      const visClicked = await waitAndClickVisibility();
      console.log(`[HM ScheduleX] Video ${processed + 1}: Visibility ${visClicked ? '✓' : '✗'}`);

      if (!visClicked) {
        await closeDialog();
        await wait(2000);
        processed++;
        continue;
      }

      // Step 3: Scroll down + Click Schedule section
      sendLiveStatus(processed, totalVideos, liveEntries, `⏳ Video ${processed+1} — Setting date & time...`);
      await wait(1500);
      const scheduleExpanded = await expandScheduleSection();
      console.log(`[HM ScheduleX] Video ${processed + 1}: Schedule expanded ${scheduleExpanded ? '✓' : '✗'}`);

      // Step 4: Select date in calendar
      if (scheduleExpanded) {
        await wait(1000);
        const dateSet = await selectScheduleDate(videoDate);
        console.log(`[HM ScheduleX] Video ${processed + 1}: Date set ${dateSet ? '✓' : '✗'}`);

        // Step 5: Set time
        await wait(800);
        const timeSet = await setScheduleTime(videoTime);
        console.log(`[HM ScheduleX] Video ${processed + 1}: Time set ${timeSet ? '✓' : '✗'}`);
      }

      // Step 6: Click Schedule button — retry logic (max 3 attempts)
      sendLiveStatus(processed, totalVideos, liveEntries, `⏳ Video ${processed+1} — Clicking Schedule...`);
      let scheduled = false;
      let attempt = 0;
      const maxAttempts = 3;

      while (!scheduled && attempt < maxAttempts) {
        attempt++;
        if (attempt > 1) {
          console.log(`[HM ScheduleX] Video ${processed + 1}: Retry attempt ${attempt}...`);
          await wait(2000);
          // Date aur time dobara set karo
          if (scheduleExpanded) {
            await selectScheduleDate(videoDate);
            await wait(800);
            await setScheduleTime(videoTime);
            await wait(1000);
          }
        }

        await wait(1000);
        scheduled = await clickScheduleButton();
        console.log(`[HM ScheduleX] Video ${processed + 1}: Attempt ${attempt} — Scheduled ${scheduled ? '✓' : '✗'}`);

        if (scheduled) {
          // Step 7: Close confirmation popup
          await wait(1500);
          await closeScheduledPopup();
          // Step 8: Page settle hone ka wait
          console.log('[HM ScheduleX] Page settle hone ka wait...');
          await wait(8000);
        }
      }

      if (!scheduled) {
        console.warn(`[HM ScheduleX] Video ${processed + 1}: ${maxAttempts} attempts ke baad bhi fail — skipping`);
        await closeDialog();
        await wait(2000);
      }

      // Live progress entry add karo
      const videoTimeTaken = Math.round((Date.now() - videoStartTime) / 1000);
      const videoCompletedAt = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
      liveEntries.push({
        videoNum: processed + 1,
        date: videoDate,
        time: videoTime,
        success: scheduled,
        attempts: attempt,
        timeTaken: videoTimeTaken, // seconds
        startedAt: videoStartedAt,   // e.g. "4:38 PM"
        completedAt: videoCompletedAt // e.g. "4:39 PM"
      });

      processed++;
      processedInThisRound = true;
      console.log(`[HM ScheduleX] Progress: ${processed}/${totalVideos} | ${scheduled ? 'OK' : 'FAILED'}`);

      // Storage mein live update bhejo — popup mein dikhega
      // persistentEntries alag key mein — refresh ke baad bhi safe rahegi
      chrome.storage.local.set({
        liveProgress: getLiveProgressData(processed, totalVideos, liveEntries),
        persistentEntries: liveEntries
      });

      // Ek video process ke baad loop restart karo — fresh buttons lene ke liye
      break;
      } // end of draft else block
    }

    // Agar koi bhi process nahi hua — next page try karo
    if (!processedInThisRound) {
      console.log('[HM ScheduleX] Koi new draft nahi mila — next page try...');
    }

    // Next page
    if (processed < totalVideos && !processedInThisRound) {
      const hasNext = clickNextPage();
      if (!hasNext) break;
      await wait(3000);
    }
  }

  console.log(`[HM ScheduleX] Done! ${processed} videos processed.`);

  // Save completion info to storage — popup mein show hoga
  const completionTime = new Date().toLocaleString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });

  // History mein session + individual video entries save karo
  const months2 = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const startD = new Date(scheduleData.start);
  const endD   = new Date(scheduleData.start);
  endD.setDate(endD.getDate() + (scheduleData.daysNeeded || 0) - 1);
  const fmt = (d) => `${String(d.getDate()).padStart(2,'0')} ${months2[d.getMonth()]} ${d.getFullYear()}`;

  const sessionEndTime = Date.now();
  const sessionDurationSec = Math.round((sessionEndTime - sessionStartTime) / 1000);
  const avgSecPerVideo = processed > 0 ? Math.round(sessionDurationSec / processed) : 0;
  const successCount = liveEntries.filter(e => e.success).length;
  const failCount    = liveEntries.filter(e => !e.success).length;

  const historyEntry = {
    date:              completionTime,
    sessionStart:      new Date(sessionStartTime).toLocaleTimeString('en-GB', {hour:'2-digit', minute:'2-digit', second:'2-digit'}),
    sessionDuration:   sessionDurationSec,
    avgSecPerVideo:    avgSecPerVideo,
    total:             scheduleData.total,
    scheduled:         successCount,
    failed:            failCount,
    remaining:         scheduleData.total - processed,
    type:              scheduleData.type,
    filter:            scheduleData.filter,
    startDate:         fmt(startD),
    endDate:           fmt(endD),
    times:             scheduleData.times || [],
    daily:             scheduleData.daily,
    videoEntries:      liveEntries
  };

  // Storage mein existing history padho aur nai entry add karo
  chrome.storage.local.get(['scheduleHistory'], (result) => {
    const history = result.scheduleHistory || [];
    history.unshift(historyEntry);
    if (history.length > 1000) history.pop();
    // schedulingRunning lock reset karo — scheduling ab khatam hui
    schedulingRunning = false;
    chrome.storage.local.set({
      scheduleHistory: history,
      lastTaskComplete: { count: processed, time: completionTime },
      liveProgress: null,
      isScheduling: false
    });
  });

  // Show task complete notification on page
  showCompletionBanner(processed);
}

// ─── Task Complete Banner ─────────────────────────────────────────────────

function showCompletionBanner(count) {
  // Remove existing banner if any
  const existing = document.getElementById('hmsx-complete-banner');
  if (existing) existing.remove();

  const banner = document.createElement('div');
  banner.id = 'hmsx-complete-banner';
  banner.style.cssText = `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #00c853, #00e676);
    color: #000;
    font-family: 'Segoe UI', sans-serif;
    font-size: 15px;
    font-weight: 700;
    padding: 14px 28px;
    border-radius: 50px;
    box-shadow: 0 8px 32px rgba(0, 200, 83, 0.5);
    z-index: 999999;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: hmsx-slide-in 0.4s ease;
    cursor: pointer;
    white-space: nowrap;
  `;

  banner.innerHTML = `
    <span style="font-size:20px">✅</span>
    <span>HM ScheduleX — ${count} video${count !== 1 ? 's' : ''} scheduled successfully!</span>
    <span style="font-size:12px; opacity:0.6; margin-left:4px">✕</span>
  `;

  // Add animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes hmsx-slide-in {
      from { opacity: 0; transform: translateX(-50%) translateY(-20px); }
      to   { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
    @keyframes hmsx-slide-out {
      from { opacity: 1; transform: translateX(-50%) translateY(0); }
      to   { opacity: 0; transform: translateX(-50%) translateY(-20px); }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(banner);

  // Click to dismiss
  banner.addEventListener('click', () => {
    banner.style.animation = 'hmsx-slide-out 0.3s ease forwards';
    setTimeout(() => banner.remove(), 300);
  });

  // Auto dismiss after 8 seconds
  setTimeout(() => {
    if (banner.parentElement) {
      banner.style.animation = 'hmsx-slide-out 0.3s ease forwards';
      setTimeout(() => banner.remove(), 300);
    }
  }, 8000);

  console.log('[HM ScheduleX] ✅ Completion banner shown!');
}

// ─── Date Calculator ──────────────────────────────────────────────────────

function getVideoDate(startDate, videoIndex, dailyVideos) {
  // Video 0,1 → Day 0 | Video 2,3 → Day 1 | etc.
  const dayOffset = Math.floor(videoIndex / dailyVideos);
  const d = new Date(startDate);
  d.setDate(d.getDate() + dayOffset);
  // Return "YYYY-MM-DD"
  return d.toISOString().split('T')[0];
}

// ─── Expand Schedule Section ──────────────────────────────────────────────

async function expandScheduleSection() {
  const maxWait = 12000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    await wait(500);

    // Console se proved:
    // div.early-access-header.style-scope.ytcp-video-visibility-select jo "Schedule" text contain kare
    const allHeaders = document.querySelectorAll(
      'div.early-access-header.style-scope.ytcp-video-visibility-select'
    );
    for (let el of allHeaders) {
      const txt = (el.innerText || el.textContent || '').trim();
      if (txt.includes('Schedule')) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await wait(400);
        el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        await wait(100);
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        await wait(800);
        console.log('[HM ScheduleX] Schedule section clicked ✓');
        return true;
      }
    }

    // Fallback: p#visibility-title = "Schedule"
    const titleEl = document.querySelector('p#visibility-title');
    if (titleEl && titleEl.textContent.trim() === 'Schedule') {
      titleEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await wait(400);
      const container = titleEl.closest('div[class*="early-access-header"]') || titleEl.parentElement;
      const target = container || titleEl;
      target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      await wait(100);
      target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      await wait(800);
      console.log('[HM ScheduleX] Schedule section clicked via p#visibility-title ✓');
      return true;
    }
  }

  console.warn('[HM ScheduleX] Schedule section NOT found!');
  return false;
}

// ─── Select Date in Calendar ──────────────────────────────────────────────

async function selectScheduleDate(targetDate) {
  // targetDate = "YYYY-MM-DD"
  // Method: Click date field → type date in "19 Apr 2026" format → press Enter

  // Format: "19 Apr 2026"
  const d = new Date(targetDate);
  // toLocaleDateString use nahi karo — har Chrome/OS mein alag result deta hai
  // Manual format: "26 Mar 2026" — hamesha same rahega
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const formatted = `${String(d.getDate()).padStart(2,'0')} ${months[d.getMonth()]} ${d.getFullYear()}`;

  // Step 1: Find the DATE span specifically (text like "28 Mar 2026")
  // There are multiple span.dropdown-trigger-text — we need the date one
  let trigger = null;
  const allSpans = document.querySelectorAll('span.dropdown-trigger-text');
  for (let sp of allSpans) {
    const txt = (sp.innerText || sp.textContent || '').trim();
    // Date pattern: "28 Mar 2026" — number + month + year
    // Dono formats handle karo:
    // "27 Mar 2026" (DD Mon YYYY) — working Chrome
    // "Mar 27, 2026" (Mon DD, YYYY) — dusre Chrome
    if (/^\d{1,2}\s+\w{3}\s+\d{4}$/.test(txt) || /^\w{3}\s+\d{1,2},\s+\d{4}$/.test(txt)) {
      trigger = sp;
      break;
    }
  }

  if (!trigger) {
    console.warn('[HM ScheduleX] Date trigger not found!');
    return false;
  }

  // Trigger ka current format detect karo
  const triggerText = trigger.innerText.trim();
  console.log('[HM ScheduleX] Trigger current text:', triggerText);

  // Format detect karke target date usi format mein convert karo
  const months2 = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const monthsFull2 = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const day = d.getDate();
  const month = d.getMonth();
  const year = d.getFullYear();
  const dd = String(day).padStart(2, '0');
  const mmm = months2[month];

  let formattedForInput;

  // Format 1: "Mar 27, 2026" (Mon DD, YYYY) — US format
  if (/^\w{3}\s+\d{1,2},\s+\d{4}$/.test(triggerText)) {
    formattedForInput = `${mmm} ${day}, ${year}`;
    console.log('[HM ScheduleX] Format detected: US (Mon DD, YYYY)');
  }
  // Format 2: "27 Mar 2026" (DD Mon YYYY) — UK format
  else if (/^\d{1,2}\s+\w{3}\s+\d{4}$/.test(triggerText)) {
    formattedForInput = `${dd} ${mmm} ${year}`;
    console.log('[HM ScheduleX] Format detected: UK (DD Mon YYYY)');
  }
  // Format 3: "27 March 2026" (DD Month YYYY)
  else if (/^\d{1,2}\s+\w+\s+\d{4}$/.test(triggerText)) {
    formattedForInput = `${dd} ${monthsFull2[month]} ${year}`;
    console.log('[HM ScheduleX] Format detected: Full month (DD Month YYYY)');
  }
  // Default: UK format
  else {
    formattedForInput = `${dd} ${mmm} ${year}`;
    console.log('[HM ScheduleX] Format: default UK');
  }

  console.log(`[HM ScheduleX] Date formatted as: ${formattedForInput}`);

  trigger.click();
  console.log('[HM ScheduleX] Date trigger clicked:', triggerText);
  await wait(800);

  // Step 2: Find the text input
  const maxWait = 5000;
  const start = Date.now();
  let inputEl = null;

  while (Date.now() - start < maxWait) {
    inputEl = document.querySelector('ytcp-date-picker input[type="text"]')
           || document.querySelector('ytcp-date-picker input')
           || document.querySelector('input.style-scope.ytcp-date-picker')
           || (() => {
                const allInputs = document.querySelectorAll('input[type="text"]');
                for (let inp of allInputs) {
                  const rect = inp.getBoundingClientRect();
                  if (rect.width > 0 && rect.height > 0) return inp;
                }
                return null;
              })();
    if (inputEl) break;
    await wait(300);
  }

  if (!inputEl) {
    console.warn('[HM ScheduleX] Date input field not found!');
    return false;
  }
  console.log('[HM ScheduleX] Date input found!');

  // Step 3: Native setter se value set karo
  inputEl.focus();
  await wait(300);

  inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', keyCode: 65, ctrlKey: true, bubbles: true }));
  await wait(100);
  inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', keyCode: 46, bubbles: true }));
  await wait(100);

  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  nativeSetter.call(inputEl, formattedForInput);
  inputEl.dispatchEvent(new Event('input',  { bubbles: true }));
  inputEl.dispatchEvent(new Event('change', { bubbles: true }));
  await wait(400);

  console.log(`[HM ScheduleX] Typed date: ${formattedForInput}`);

  // Step 4: Enter press
  inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
  inputEl.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
  inputEl.dispatchEvent(new Event('blur', { bubbles: true }));
  await wait(800);

  console.log(`[HM ScheduleX] Date ${targetDate} set ✓`);
  return true;
}

// ─── Close "Video Scheduled" Popup ──────────────────────────────────────

async function closeScheduledPopup() {
  const maxWait = 5000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    // Method 1: "Close" button text dhundo
    const allBtns = document.querySelectorAll('ytcp-button, button, tp-yt-paper-button');
    for (let btn of allBtns) {
      const text = (btn.innerText || btn.textContent || '').trim();
      if (text === 'Close') {
        const rect = btn.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          btn.click();
          console.log('[HM ScheduleX] Scheduled popup closed ✓');
          await wait(1000);
          return true;
        }
      }
    }

    // Method 2: Dialog close button
    const closeBtn = document.querySelector(
      'ytcp-video-scheduled-dialog [aria-label="Close"], ' +
      'ytcp-dialog[active] ytcp-button[aria-label="Close"], ' +
      '.ytcp-video-scheduled-dialog ytcp-button'
    );
    if (closeBtn) {
      closeBtn.click();
      console.log('[HM ScheduleX] Scheduled popup closed via dialog selector ✓');
      await wait(1000);
      return true;
    }

    await wait(300);
  }

  console.log('[HM ScheduleX] No scheduled popup found — continuing...');
  return false;
}

// ─── Click Schedule Button ───────────────────────────────────────────────

async function clickScheduleButton() {
  // Pehle 2 second wait karo — YouTube ko date/time process karne ka time do
  await wait(2000);

  const maxWait = 8000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    const allBtns = document.querySelectorAll('ytcp-button');
    for (let btn of allBtns) {
      const text = (btn.innerText || btn.textContent || '').trim();
      if (text === 'Schedule') {
        // Check if button is enabled
        if (btn.disabled || btn.hasAttribute('disabled')) {
          console.log('[HM ScheduleX] Schedule button disabled hai, wait kar raha hun...');
          await wait(500);
          break; // Retry loop
        }
        console.log('[HM ScheduleX] Schedule button found & enabled! Clicking...');
        btn.click();
        await wait(2000);
        return true;
      }
    }
    await wait(500);
  }

  // Last resort: force click even if disabled
  const allBtns = document.querySelectorAll('ytcp-button');
  for (let btn of allBtns) {
    const text = (btn.innerText || btn.textContent || '').trim();
    if (text === 'Schedule') {
      console.log('[HM ScheduleX] Force clicking Schedule button...');
      btn.removeAttribute('disabled');
      btn.click();
      await wait(2000);
      return true;
    }
  }

  console.warn('[HM ScheduleX] Schedule button not found!');
  return false;
}


// ─── Close "Video Scheduled" Popup ──────────────────────────────────────

async function closeScheduledPopup() {
  const maxWait = 6000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    // Method 1: "Video scheduled" heading wala dialog dhundo
    const allEls = document.querySelectorAll('h1, h2, h3, div, span, p');
    let foundHeading = false;
    for (let el of allEls) {
      const t = (el.innerText || el.textContent || '').trim();
      if (t === 'Video scheduled') {
        foundHeading = true;
        // Parent dialog mein Close button dhundo
        let parent = el.parentElement;
        for (let i = 0; i < 8; i++) {
          if (!parent) break;
          const btns = parent.querySelectorAll('button, ytcp-button');
          for (let btn of btns) {
            const bt = (btn.innerText || btn.textContent || '').trim();
            if (bt === 'Close') {
              console.log('[HM ScheduleX] "Video scheduled" popup Close clicked!');
              btn.click();
              await wait(1000);
              return true;
            }
          }
          parent = parent.parentElement;
        }
        break;
      }
    }

    // Method 2: Visible "Close" button dhundo
    const allBtns = document.querySelectorAll('button, ytcp-button');
    for (let btn of allBtns) {
      const text = (btn.innerText || btn.textContent || '').trim();
      if (text === 'Close') {
        const rect = btn.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          console.log('[HM ScheduleX] Close button clicked!');
          btn.click();
          await wait(1000);
          return true;
        }
      }
    }

    // Method 3: X button (dialog close icon)
    const xBtns = document.querySelectorAll('[aria-label="Close"], [aria-label="close"]');
    for (let btn of xBtns) {
      const rect = btn.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        // Sirf tab click karo jab "Video scheduled" popup visible ho
        if (foundHeading || document.querySelector('tp-yt-paper-dialog[opened]')) {
          console.log('[HM ScheduleX] X button clicked!');
          btn.click();
          await wait(1000);
          return true;
        }
      }
    }

    await wait(300);
  }

  console.log('[HM ScheduleX] No scheduled popup found — continuing...');
  return false;
}

// ─── Confirm Time Input (Enter + blur after dropdown click) ──────────────

async function confirmTimeInput(targetTime) {
  // Time input dhundo aur Enter + blur fire karo
  const inputEl = document.querySelector('input.style-scope.tp-yt-paper-input')
                || document.querySelector('tp-yt-paper-input input')
                || document.querySelector('ytcp-dropdown-trigger[compact] input');
  if (!inputEl) return;

  // Focus
  inputEl.focus();
  await wait(200);

  // Enter keydown - YouTube Schedule button activate karne ke liye
  inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
  inputEl.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
  await wait(300);

  // Blur
  inputEl.dispatchEvent(new Event('blur', { bubbles: true }));
  await wait(300);

  console.log(`[HM ScheduleX] confirmTimeInput fired for ${targetTime}`);
}

// ─── Set Time ────────────────────────────────────────────────────────────

function convertTo24Hour(timeStr) {
  // "05:00 PM" → "17:00" | "12:00 AM" → "00:00" | "07:00" → "07:00" (already 24hr)
  if (!timeStr) return '00:00';
  timeStr = timeStr.trim();
  const match = timeStr.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!match) return timeStr; // Already 24hr format
  let h = parseInt(match[1]);
  const m = match[2];
  const period = match[3].toUpperCase();
  if (period === 'AM' && h === 12) h = 0;
  if (period === 'PM' && h !== 12) h += 12;
  return `${String(h).padStart(2, '0')}:${m}`;
}

function convertTo12Hour(time24) {
  // "22:00" → "10:00 PM" | "00:00" → "12:00 AM" | "12:00" → "12:00 PM"
  if (!time24) return '12:00 AM';
  const [hStr, mStr] = time24.split(':');
  let h = parseInt(hStr);
  const m = mStr || '00';
  const period = h >= 12 ? 'PM' : 'AM';
  if (h === 0) h = 12;
  else if (h > 12) h -= 12;
  return `${h}:${m} ${period}`;
}

async function setScheduleTime(targetTime) {
  // targetTime popup se aata hai — pehle 24hr mein convert karo
  targetTime = convertTo24Hour(targetTime);
  console.log(`[HM ScheduleX] Time converted to 24hr: ${targetTime}`);

  // Step 1: Time trigger dhundo aur uska current format detect karo
  const allTriggers = document.querySelectorAll('ytcp-dropdown-trigger');
  let timeTrigger = null;
  for (let t of allTriggers) {
    if (t.hasAttribute('compact')) { timeTrigger = t; break; }
  }
  if (!timeTrigger) {
    console.warn('[HM ScheduleX] Time trigger not found!');
    return false;
  }

  // Trigger ka current text padho — format detect karo
  const triggerTimeText = (timeTrigger.innerText || timeTrigger.textContent || '').trim();
  console.log(`[HM ScheduleX] Time trigger current text: "${triggerTimeText}"`);

  // Format detect: AM/PM hai toh 12hr, warna 24hr
  const is12HrFormat = /AM|PM/i.test(triggerTimeText);
  console.log(`[HM ScheduleX] Time format: ${is12HrFormat ? '12-hour (AM/PM)' : '24-hour'}`);

  // Target time ko sahi format mein convert karo
  const timeToType = is12HrFormat ? convertTo12Hour(targetTime) : targetTime;
  console.log(`[HM ScheduleX] Will type time as: "${timeToType}"`);

  timeTrigger.click();
  console.log('[HM ScheduleX] Time trigger clicked, waiting for dropdown...');
  await wait(800);

  // Dropdown mein bhi sahi format dhundo
  const dropdownTime = is12HrFormat ? convertTo12Hour(targetTime) : targetTime;

  // Step 2: Dropdown se time click karo — sahi format mein
  const clicked = await clickTimeFromDropdown(dropdownTime);
  if (clicked) {
    console.log(`[HM ScheduleX] Time ${dropdownTime} dropdown se set ✓`);
    return true;
  }

  // Step 3: Dropdown nahi mila — input field mein type karo
  console.log('[HM ScheduleX] Dropdown option nahi mila, input mein type kar raha hun...');
  const inputEl = await findVisibleTimeInput();
  if (!inputEl) {
    console.warn('[HM ScheduleX] Time input bhi nahi mila!');
    return false;
  }

  // Native setter se value set karo
  const nativeInputSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;

  // 3 baar try karo
  for (let attempt = 1; attempt <= 3; attempt++) {
    nativeInputSetter.call(inputEl, timeToType);
    inputEl.dispatchEvent(new Event('input',  { bubbles: true }));
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    await wait(300);

    // Tab key — YouTube value commit karta hai Tab se
    inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', keyCode: 9, bubbles: true, cancelable: true }));
    inputEl.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Tab', keyCode: 9, bubbles: true }));
    await wait(300);

    // Blur + focusout
    inputEl.dispatchEvent(new FocusEvent('blur',     { bubbles: true }));
    inputEl.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    await wait(500);

    const currentVal2 = inputEl.value;
    console.log(`[HM ScheduleX] Attempt ${attempt}: Time value = "${currentVal2}"`);

    if (currentVal2 === timeToType || convertTo24Hour(currentVal2) === targetTime) {
      console.log(`[HM ScheduleX] Time ${timeToType} confirmed ✓`);
      break;
    }
  }

  console.log(`[HM ScheduleX] Time ${timeToType} input se set ✓`);
  await wait(800);
  return true;
}


async function findVisibleTimeInput() {
  const maxWait = 3000;
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    const allInputs = document.querySelectorAll('input.style-scope.tp-yt-paper-input');
    // Pehle: HH:MM value wala input dhundo
    for (let inp of allInputs) {
      const rect = inp.getBoundingClientRect();
      if (rect.width > 0 && /^\d{2}:\d{2}$/.test(inp.value)) return inp;
    }
    // Phir: aria-labelledby wala visible input
    for (let inp of allInputs) {
      const rect = inp.getBoundingClientRect();
      if (rect.width > 0 && inp.getAttribute('aria-labelledby')) return inp;
    }
    // Last resort: koi bhi visible input
    for (let inp of allInputs) {
      const rect = inp.getBoundingClientRect();
      if (rect.width > 0) return inp;
    }
    await wait(300);
  }
  return null;
}

async function clickTimeFromDropdown(targetTime) {
  // targetTime = "HH:MM" 24-hour format e.g. "18:00"
  // Dropdown 00:00 se start hota hai — target time neeche ho sakta hai
  // scrollIntoView se item visible karke click karo

  const maxWait = 5000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    const allItems = getAllDropdownItems();

    if (allItems.length === 0) {
      await wait(300);
      continue;
    }

    // Pehle exact match dhundo — scroll karke visible karo phir click
    for (let item of allItems) {
      const text = (item.innerText || item.textContent || '').trim();
      if (text === targetTime) {
        // Scroll karke center mein lao
        item.scrollIntoView({ behavior: 'instant', block: 'center' });
        await wait(300);
        item.click();
        await wait(600);
        console.log(`[HM ScheduleX] Exact dropdown match clicked: ${text}`);
        return true;
      }
    }

    // Nearest match — scroll karke click
    const nearest = findNearestTimeOption(targetTime, allItems);
    if (nearest) {
      nearest.el.scrollIntoView({ behavior: 'instant', block: 'center' });
      await wait(300);
      nearest.el.click();
      await wait(600);
      console.log(`[HM ScheduleX] Nearest dropdown match clicked: ${nearest.text}`);
      return true;
    }

    await wait(300);
  }

  return false;
}

function getAllDropdownItems() {
  // Multiple selectors — YouTube ka UI change hota rehta hai
  const selectors = [
    'tp-yt-paper-item',
    'paper-item',
    '[role="option"]',
    '[role="listitem"]',
    'ytcp-text-menu paper-item',
    'ytcp-text-menu tp-yt-paper-item',
  ];

  for (let sel of selectors) {
    const items = Array.from(document.querySelectorAll(sel)).filter(el => {
      const text = (el.innerText || el.textContent || '').trim();
      return /^\d{2}:\d{2}$/.test(text);
    });
    if (items.length > 0) return items;
  }

  // Last resort: page ke saare visible leaf elements mein HH:MM text dhundo
  const timeItems = [];
  for (let el of document.querySelectorAll('*')) {
    if (el.children.length > 0) continue;
    const text = (el.innerText || el.textContent || '').trim();
    if (/^\d{2}:\d{2}$/.test(text)) {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) timeItems.push(el);
    }
  }
  return timeItems;
}

function findNearestTimeOption(targetTime, items) {
  // targetTime = "HH:MM" — sabse qareeb wala 15-min slot dhundo
  const [tH, tM] = targetTime.split(':').map(Number);
  const targetMins = tH * 60 + tM;

  let best = null;
  let bestDiff = Infinity;

  for (let item of items) {
    const text = (item.innerText || item.textContent || '').trim();
    // Format "HH:MM" match karo
    if (!/^\d{2}:\d{2}$/.test(text)) continue;
    const [h, m] = text.split(':').map(Number);
    const mins = h * 60 + m;
    const diff = Math.abs(mins - targetMins);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = { el: item, text };
    }
  }

  // Sirf 30 minute ke andar ka nearest accept karo
  return bestDiff <= 30 ? best : null;
}


function findDateInput() {
  // Method 1: input inside schedule/date area
  const inputs = document.querySelectorAll(
    'ytcp-date-picker input, input[placeholder*="date"], input[aria-label*="date"], input[aria-label*="Date"]'
  );
  if (inputs.length > 0) return inputs[0];

  // Method 2: ytcp-date-picker click trigger
  const datePicker = document.querySelector('ytcp-date-picker');
  if (datePicker) return datePicker;

  // Method 3: div that shows date like "26 Mar 2026"
  const allDivs = document.querySelectorAll('div[class*="date"], span[class*="date"]');
  for (let d of allDivs) {
    const text = (d.innerText || d.textContent || '').trim();
    if (/\d{1,2}\s+\w+\s+\d{4}/.test(text)) return d;
  }

  return null;
}

async function tryPickDate(targetDate) {
  // targetDate = "YYYY-MM-DD"
  const target = new Date(targetDate);
  const targetDay   = target.getDate();           // e.g. 26
  const targetMonth = target.getMonth();          // 0-indexed
  const targetYear  = target.getFullYear();

  // Method 1: Direct input field — type the date
  const inputField = document.querySelector(
    'ytcp-date-picker input[type="text"], input[aria-label*="date"], input[aria-label*="Date"]'
  );
  if (inputField) {
    inputField.focus();
    inputField.value = '';
    // Format: DD Mon YYYY e.g. "26 Mar 2026"
    const months2 = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const formatted = `${String(target.getDate()).padStart(2,'0')} ${months2[target.getMonth()]} ${target.getFullYear()}`;
    inputField.value = formatted;
    inputField.dispatchEvent(new Event('input', { bubbles: true }));
    inputField.dispatchEvent(new Event('change', { bubbles: true }));
    await wait(500);

    // Press Enter to confirm
    inputField.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    await wait(500);
    return true;
  }

  // Method 2: Calendar grid — find and click the date cell
  // Navigate to correct month first
  await navigateCalendarToMonth(targetYear, targetMonth);
  await wait(500);

  // Find date cell
  const cells = document.querySelectorAll(
    'td[data-day], div[data-day], [aria-label*="' + targetDay + '"]'
  );
  for (let cell of cells) {
    const label = (cell.getAttribute('aria-label') || cell.textContent || '').trim();
    const dayNum = parseInt(cell.getAttribute('data-day') || cell.textContent);
    if (dayNum === targetDay) {
      cell.click();
      await wait(500);
      return true;
    }
  }

  return false;
}

async function navigateCalendarToMonth(targetYear, targetMonth) {
  // Max 24 clicks to navigate
  for (let i = 0; i < 24; i++) {
    const currentMonth = getCurrentCalendarMonth();
    if (!currentMonth) break;

    if (currentMonth.year === targetYear && currentMonth.month === targetMonth) break;

    // Determine direction
    const currentDate = new Date(currentMonth.year, currentMonth.month, 1);
    const targetDt    = new Date(targetYear, targetMonth, 1);

    if (targetDt > currentDate) {
      // Click Next
      const nextBtn = document.querySelector(
        'button[aria-label="Next month"], ytcp-icon-button[aria-label*="next"], [aria-label*="Next"]'
      );
      if (nextBtn) { nextBtn.click(); await wait(500); }
      else break;
    } else {
      // Click Prev
      const prevBtn = document.querySelector(
        'button[aria-label="Previous month"], ytcp-icon-button[aria-label*="prev"], [aria-label*="Previous"]'
      );
      if (prevBtn) { prevBtn.click(); await wait(500); }
      else break;
    }
  }
}

function getCurrentCalendarMonth() {
  // Try to read current month/year from calendar header
  const header = document.querySelector(
    '.calendar-header, [class*="calendar"] [class*="month"], [class*="calendar"] [class*="header"]'
  );
  if (!header) return null;

  const text = (header.innerText || header.textContent || '').trim();
  // e.g. "MAR 2026" or "March 2026"
  const months = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
  const parts = text.toLowerCase().split(/\s+/);
  let month = -1, year = -1;
  for (let p of parts) {
    const mi = months.findIndex(m => p.startsWith(m));
    if (mi !== -1) month = mi;
    if (/^\d{4}$/.test(p)) year = parseInt(p);
  }
  if (month === -1 || year === -1) return null;
  return { month, year };
}

// ─── Wait for dialog then click Visibility ───────────────────────────────

async function waitAndClickVisibility() {
  const maxWait = 6000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    await wait(500);
    const visTab = findVisibilityTab();
    if (visTab) {
      console.log('[HM ScheduleX] Visibility tab found! Clicking...');
      visTab.click();
      await wait(1000);
      return true;
    }
  }
  return false;
}

function findVisibilityTab() {
  const direct = document.querySelector('button#step-badge-3');
  if (direct) return direct;

  const allBadges = document.querySelectorAll('button[id^="step-badge-"]');
  if (allBadges.length > 0) return allBadges[allBadges.length - 1];

  const stepperBtns = document.querySelectorAll('ytcp-stepper button');
  if (stepperBtns.length > 0) return stepperBtns[stepperBtns.length - 1];

  return null;
}

// ─── Private Video: Close ALL open panels ────────────────────────────────

async function closePrivatePanel() {
  // Saare visible Cancel buttons click karo — ek se zyada panels ho sakte hain
  let closedCount = 0;

  const allBtns = Array.from(document.querySelectorAll('ytcp-button, button, tp-yt-paper-button'));
  for (let btn of allBtns) {
    const text = (btn.innerText || btn.textContent || '').trim();
    if (text === 'Cancel') {
      const rect = btn.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        btn.click();
        closedCount++;
        await wait(400);
      }
    }
  }

  if (closedCount > 0) {
    console.log(`[HM ScheduleX] ${closedCount} panel(s) closed via Cancel ✓`);
    await wait(600);
    return true;
  }

  // Fallback: Escape key — ek panel band karta hai
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
  await wait(300);
  document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', keyCode: 27, bubbles: true }));
  await wait(600);
  console.log('[HM ScheduleX] Private panel closed via Escape ✓');
  return true;
}

// ─── Private Video: Find clickable "Private" elements ────────────────────

async function waitForPrivateVideoBadges(maxWait = 8000) {
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    const badges = findPrivateVideoBadges();
    if (badges.length > 0) return badges;
    await wait(500);
  }
  return [];
}

function findPrivateVideoBadges() {
  // Sirf woh editable divs lo jinka andar "Private" text ho
  // "Scheduled" wale skip karo — woh already process ho chuke hain
  const candidates = Array.from(
    document.querySelectorAll('div.icon-text-edit-triangle-wrap.editable')
  ).filter(el => {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const txt = (el.innerText || el.textContent || '').trim();
    return txt.includes('Private') && !txt.includes('Scheduled');
  });

  if (candidates.length > 0) return candidates;

  // Fallback: span.label-span jo "Private" text contain kare
  const fallback = [];
  document.querySelectorAll('span.label-span').forEach(el => {
    const txt = (el.innerText || el.textContent || '').trim();
    if (txt === 'Private') {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        const clickable = el.closest('div.icon-text-edit-triangle-wrap') || el.parentElement;
        if (clickable && !fallback.includes(clickable)) fallback.push(clickable);
      }
    }
  });
  return fallback;
}

// ─── Private Video: Click "Schedule" in dropdown ──────────────────────────

async function clickScheduleOptionInDropdown() {
  const maxWait = 5000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    // Dropdown mein "Schedule" option dhundo
    const allEls = document.querySelectorAll(
      'tp-yt-paper-item, paper-item, [role="option"], [role="menuitem"], ytcp-text-menu *'
    );
    for (let el of allEls) {
      const text = (el.innerText || el.textContent || '').trim();
      if (text === 'Schedule') {
        const rect = el.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          el.click();
          await wait(800);
          console.log('[HM ScheduleX] Schedule option clicked in dropdown ✓');
          return true;
        }
      }
    }
    await wait(300);
  }

  console.warn('[HM ScheduleX] Schedule option not found in dropdown!');
  return false;
}

// ─── Find Edit Draft Buttons ──────────────────────────────────────────────

async function waitForEditDraftButtons(maxWait = 8000) {
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    const btns = findEditDraftButtons();
    if (btns.length > 0) return btns;
    await wait(500);
  }
  return [];
}

function findEditDraftButtons() {
  const all = Array.from(document.querySelectorAll(
    'ytcp-button, button, div[role="button"]'
  ));
  return all.filter(el => {
    const text = (el.innerText || el.textContent || '').trim().toLowerCase();
    return text === 'edit draft';
  });
}

// ─── Close Dialog ─────────────────────────────────────────────────────────

async function closeDialog() {
  const selectors = [
    'ytcp-icon-button[aria-label="Close"]',
    'button[aria-label="Close"]',
    '#close-button',
    'ytcp-uploads-dialog #close-button',
  ];
  for (let sel of selectors) {
    const btn = document.querySelector(sel);
    if (btn) { btn.click(); await wait(500); return; }
  }
}

// ─── Next Page ────────────────────────────────────────────────────────────

function clickNextPage() {
  const selectors = [
    'button[aria-label="Next page"]:not([disabled])',
    'ytcp-icon-button[aria-label="Next page"]:not([disabled])'
  ];
  for (let sel of selectors) {
    const btn = document.querySelector(sel);
    if (btn) { btn.click(); return true; }
  }
  return false;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
